    <!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilsindex.css">
    
    <title>GI3PEDRALBRES</title>

</head>
<body>
    <header>
        <img src="img/logo.png" alt="">
        <h1>Gestió incidències informàtiques <br> Institut Pedralbes</h1>
    </header>
<div>
<form method="post" action="login.php">
Usuari: <input type="text" name="userid" autocomplete="off" required><br><br>
Contrasenya: <input type="password" name="password" required><br><br>
<input type="submit" value="Login">

</form>
</div>

<br>
<div class="usuaris">
    <a href='indexUsuari.php'> <input type="submit" value ="Area d'Usuaris"></a>
</div>

<footer>Institut Pedralbes 2023 <br>
    Projecte realitzat per: <br><br> Aitor · Alex · Miquel · Eric
    </footer>
</body>
</html>
