<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estils.css">
    
    <title>GI3PEDRALBRES</title>

</head>
<body>
    
    
<div class="granContenidor">

    <header>
        
         <a href="index.php" ><img src="img/logo.png" alt=""></a>
        <h1>Gestió incidències informàtiques <br> Institut Pedralbes</h1>
        

    </header>

    
        <div id="usuari">
            <h2>Usuari</h2>
            <a href="insertarIncidencia.php" target="blank">
            <div class="grid_item">
                <p>
                Insertar Incidència
            </p>
            </div>
        </a>

         <a href="listadoUsuario.php" target="blank">
            <div class="grid_item">
                <p>
                    Llistat d'Incidències
                </p>
            </div>
            </a> 

        <a href="buscarIncidenciaUsuari.php" target="blank">
            <div class="grid_item">
                <p>
                    Consultar Incidència
                </p>
            </div>
            </a>
        </div>
        <a href="logout.php" target="blank">
            <div class="grid_item">
                <p>
                Login
            </p>
            </div>
            
        </a>
        </div>
    </div>
</div>

    <footer>Institut Pedralbes 2023 <br>
    Projecte realitzat per: <br><br> Aitor · Alex · Miquel · Eric
    </footer>


</body>
</html>

