<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
    <link rel="stylesheet" href="estils.css">
</head>
<body>
<a href="indexUsuari.php"><img src="img/logo.png" alt=""></a>
<h2> Error: el ID introduit es incorrecte</h2>
<p> <button ><a href="indexUsuari.php">Tornar</a></button>
<footer>Institut Pedralbes 2023 <br>
    Projecte realitzat per: <br><br> Aitor · Alex · Eric · Miquel 
    </footer>
</body>
</html>
